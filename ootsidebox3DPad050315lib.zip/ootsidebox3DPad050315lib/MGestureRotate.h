#ifndef MgestureRotate_
#define MgestureRotate_


#define SEUIL_SENSIBILITE_ROTATE 0.03

#define ROTATION_VOID 0
#define ROTATION_RIGHT 1
#define ROTATION_LEFT  -1

void GestureRotate(void);




#endif
