#ifndef Mlinearisation_
#define Mlinearisation_

#define ECART 0
#define DIST 1

#define CONSIGNE_ELECTRODES 155

int Linearise(unsigned int M);

#endif
