#ifndef MgestureGlobale_
#define MgestureGlobale_

void GestureGlobale(void);


#endif
