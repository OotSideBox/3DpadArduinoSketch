#ifndef MAGesture_
#define MAGesture_

#define NombreEl 4
#define ECART 0 
#define DIST 1

#define SEUILMOUVXYZ 0.02 



void AutomateGesture(int offsetX,int offsetY);


#endif
