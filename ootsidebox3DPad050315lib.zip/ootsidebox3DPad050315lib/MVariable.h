#ifndef Mvariable_
#define Mvariable_

//*** Variable coordonnes ****************
struct CoordTypeAbs
	{
        int X;
        int Y;
        int Z;
    };
struct CoordTypeDyn
	{
        float X;
        float Y;
        float Z;
    };



#endif
