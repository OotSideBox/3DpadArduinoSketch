#ifndef Regulation_H_
#define Regulation_H_


void Regulation(unsigned int BaseTempsRegulation, unsigned char Touch); 

#endif