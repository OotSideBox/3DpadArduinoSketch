#ifndef MGestureTranslate_
#define MGestureTranslate_
#include "Parameters.h"

void GestureTranslate(void);



#endif
