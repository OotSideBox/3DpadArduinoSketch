#ifndef MTransMMtoAff_
#define MTransMMtoAff_
#include "Parameters.h"

void MMtoAff(void);
void ButMMtoAff(void);


#endif
