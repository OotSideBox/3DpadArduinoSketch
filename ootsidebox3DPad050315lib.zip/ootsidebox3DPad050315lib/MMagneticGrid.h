#ifndef MmagneticGrid_
#define MmagneticGrid_
#include "Parameters.h"



void MagnetGrid(  struct CoordTypeAbs *Point);
int FindNearGridPoint(int Coord);

#endif
