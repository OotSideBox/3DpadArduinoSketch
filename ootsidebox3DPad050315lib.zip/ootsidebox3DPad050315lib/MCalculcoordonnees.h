#ifndef Mcalculcoordonnees_
#define Mcalculcoordonnees_
#include "Parameters.h"



void CoordXYcompute(int c,int a,int b,int *AH,int *Z);

int CoordZcompute(int Zx, int Zy);


#endif
