#ifndef PRIMITIVE8PAR8_H_
#define PRIMITIVE8PAR8_H_


void SelectE(int NumElec);

void SPIsendForDac(unsigned int Data );


#endif /*PRIMITIVE8PAR8_H_*/
